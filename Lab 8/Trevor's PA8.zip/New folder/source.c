// source.c file
#include "Header.h"
//TASK 1 CODE
void my_str_n_cpy (char *source_char, char *destination_char, int destination_length, int number) {
	int string_position;									  //Destination length max size of the destination array
															  //number is the max length of characters to copy
	for (string_position = 0; (source_char[string_position] != '\0' && string_position < number); string_position++) {
		destination_char[string_position] = source_char[string_position];
	}
	while (string_position < destination_length) { 
		destination_char[string_position] = '\0';
		string_position++; /* This while loop fills in all of the remaining elements of the
		destination character array to be null characters so a nice string can be printed to string that 
		doesnt end in odd symbols*/
	} 
}
//TASK 2 CODE
void binary_search (int number_list[], int maxpos, int target_value, int *position, int *true_false) {
	int minpos = 0, midpos, run = 1;
	while (run == 1) {
		midpos = ((maxpos+minpos) / 2); 
		if ((maxpos-minpos) == 1) { 
			if (number_list[maxpos] == target_value) {
				*true_false = 1;
				*position = maxpos;
			}
			else if (number_list[minpos] == target_value)  {
				*true_false = 1;
				*position = minpos;
			}
			else {
				*true_false = 0;
				*position = 0;
			}
			run = 0;
		}
		else {
			if (number_list[midpos] < target_value) {
				minpos = midpos;
			}
			else if (number_list[midpos] > target_value) {
				maxpos = midpos;
			}
			else {
				*true_false = 1;
				*position = midpos;
				run = 0;
			}
		}
	}
}
//TASK 3 CODE
void bubble_sort (char *set[], int size) { 
	int index1, index2 = 0, length = (size-1);
	char *temp;
	while (index2 < (size-1)) {
		for (index1 = 0; index1 < length; index1++) {
			if (strlen(set[index1]) > strlen(set[index1+1])) {
				temp = set[index1];
				set[index1] = set[index1+1];
				set[index1+1] = temp;
			}
		}
		length -= 1;
		index2 += 1;
	} 
}
//TASK 4 CODE
void is_palindrome (char *phrase, int size, int start, int finish, int *yes_no) {
	int run = 1;
	if (start <= (size / 2) && run == 1) {
		if (phrase[start] == ' ') {
			start += 1;
			size -= 1;
		}
		if (phrase[finish] == ' ') {
			finish -= 1;
			size -= 1;
		}
		if (phrase[start] == phrase[finish]) {
			is_palindrome (phrase, size, start+1, finish-1, yes_no);
		}
		else {
			run = 0;
		}
	}
	if (run == 1) {
		*yes_no = 1;
	}
	else {
		*yes_no = 0;
	}
}
//TASK 5 CODE
void sum_primes (int number, int current, int *sum) {
	int divide = 2, run = 1; 
	if (current <= number) {
		while (divide <= (current/2) && run == 1) {
			if (current % divide == 0 && current != 0 && current != 1) {
				run = 0;
			}
			divide += 1;
		}
		if (run == 1 && current >= 2) { //def of prime is n <= 2 & for all e from 2 to n -> n%e != 0.
			*sum += current;
		}
		sum_primes (number, current+1, sum);
	}
} 
//TASK 6 CODE
void maximum_occurences (char *alpha_num, Occurrences structs_array[], int *integer, char *character) {
	int index = 0, index2 = 0, index3 = 0, char_num, char_max = 0, len = strlen(alpha_num);
	while (index2 < 123) { //122 is the maximum asscii value for any avaialble alphanums
		structs_array[index2].num_occurrences = 0; //this initiallizes everything to 0 & 1;
		structs_array[index2].frequency = 0;
		index2 += 1;
	}
	while (index < len) {
		char_num = ("%d", alpha_num[index]); //I changed the character to it ascii number value
		structs_array[char_num].num_occurrences += 1;
		structs_array[char_num].frequency = ((double) structs_array[char_num].num_occurrences) / ((double)len);
		index += 1;
	}
	*integer = 0;
	while (index3 < len) {
		char_num = ("%d", alpha_num[index3]);
		if (structs_array[char_num].num_occurrences > *integer) {
			*integer = structs_array[char_num].num_occurrences; //max occurences
			char_max = char_num;
		}
		index3 += 1;
	}
	*character = ("%c", char_max); //this changes ascii value back to character; */
}
