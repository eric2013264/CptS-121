// main.c file
/*
Trevor Mozingo
CPTS 121-03
PA8
*/
#include "Header.h"
int main (void) {
//TASK 1 TEST CODE 
	/*
	char *source = "This is just a test string";
	char destination[30];
	my_str_n_cpy (source, destination, 30, 3); 
	printf("%s\n", destination);
	*/
//TASK 2 TEST CODE
	/*
	int a[5] = {1,2,3,4}, pos = 0, t; //t is truth value, pos is position.
	binary_search(a,3,3,&pos, &t);	//the first three is the max position of the array (a[3] == 4); second 3 is target value
	printf("%d   %d", pos, t);		//print statement printing the array position; second element (truth value) returns 1 if the element is in the array 0 if not
	*/
//TASK 3 TEST CODE
	/*
	int b = 0;
	char *a[5] = {"a","aab","fanceeef","ffa","Efww"};
	bubble_sort(a, 5);
	while (b < 5) {
		printf("%s    \n", a[b]);
		b+=1;
	}
	*/
//TASK 4 TEST CODE
	/*
	char *t = "race car";
	int y;
	is_palindrome(t, 8, 0, 7, &y);
	printf("\n%d\n", y);
	*/
//TASK 5 TEST CODE
	/*
	int a = 0;
	sum_primes(7,0,&a);
	printf("\n%d\n", a);
	*/
//TASK 6 CODE
	/*
	Occurrences character[123];
	char *s = "aaabtraaacwRfC9Wcr", max_occur_char;
	int occur, n;
	maximum_occurences (s, character, &occur, &max_occur_char);
	printf("\nMaximum occuring character: %c\n", max_occur_char);
	printf("\nOccuring %d times\n", occur);
	printf("\nFrequency of character: %lf\n",  character[max_occur_char].frequency);
	*/
//TASK 7 CODE
}